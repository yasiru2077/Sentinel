package com.yasiru.Sentinel.controller;

import com.yasiru.Sentinel.dto.request.CompanyPositionsRequest;
import com.yasiru.Sentinel.dto.response.CompanyPositionResponse;
import com.yasiru.Sentinel.entity.User;
import com.yasiru.Sentinel.service.CompanyPositionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/position")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class PositionController {

    private final CompanyPositionService companyPositionService;

    @PostMapping
    public ResponseEntity<CompanyPositionResponse> createPosition(
            @Valid @RequestBody CompanyPositionsRequest request,
            @AuthenticationPrincipal User admin
            ){
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(companyPositionService.createPosition(request, admin.getId()));
    }

}
